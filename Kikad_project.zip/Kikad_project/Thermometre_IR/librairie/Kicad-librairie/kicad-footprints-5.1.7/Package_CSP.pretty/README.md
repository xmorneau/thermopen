# Housings_CSP.pretty
CSP (Chip Scale Package) footprints
